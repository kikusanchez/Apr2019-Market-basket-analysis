#Wifi Data Explorations
#Jordi Rojo
#12.02.2019



#### inicialization ####

options(max.print=50)

#folder of the github root. (my project is just one folder away)
GitDirect <- "./MarketBasketAnalysis/"


source(paste(GitDirect,"1 - Inicialization and Libraries.R",sep=""))
libraries_function()


no_cores <- detectCores() - 1
cl <- makeCluster(no_cores)
registerDoParallel(cl)
on.exit(stopCluster(cl))



#first read and binding of data.
source(paste(GitDirect,"2 - Reading Trans.R",sep=""))

source(paste(GitDirect,"2 - Reading CSV.R",sep=""))



# Loading transactions to later divide into B2c B2B

ElectoCSV <- retrieve_last_file(paste(getwd(),"/csv/",sep=""),"ElectronidexTransactions2017")


 
#### Product categorization ####
ProdsCats <- retrieve_last_fileSC(paste(getwd(),"/csv/",sep=""),"Products&Categories")


ProdsCats$Roww <- 1:nrow(ProdsCats) 

ProdsCats1_5 <- 
#tail(
ProdsCats %>% melt(id.vars = c("Roww") ) %>%
  mutate(value = str_trim(value, side = c("both")
  )) %>%
  filter (value !=  "") %>% arrange(variable) %>% select(variable,value) %>% unique()
#) 

ProdsCats1_5 %>% select(ProdCat) %>% unique()



colnames(ProdsCats1_5)[1] <- "ProdCat"
colnames(ProdsCats1_5)[2] <- "ProdName"


ProdsCats2 %>% filter ( = )

ProdsCats2 <-
  ProdsCats1_5 %>% mutate(ProdSuperCat = case_when (ProdCat == "Laptops" ~ "Laptops",
                                                ProdCat == "Desktop" ~ "Desktop",
                                                ProdCat == "Printers" ~ "Printers",
                                                ProdCat == "Monitors" ~ "Monitors",
                                                ProdCat == "Keyboar" |
                                                  ProdCat == "Mous.and.Keyboar.Combo" |
                                                  ProdCat == "Compu.Mice"
                                                ~ "MousOrKeyb",
                                                TRUE ~ "Others") 
) %>% mutate(BWCat = case_when (ProdCat == "Laptops" ~ "Laptop",
                                ProdCat == "Desktop" ~ "PC",
                                ProdCat == "Printers" ~ "Printer",
                                ProdCat == "Monitors" ~ "Display",
                                ProdCat == "Printer.Ink" ~ "Printer Supplies",
                                ProdCat == "Computer.Tablets"~ "Tablet",
                                ProdName == "Microsoft Office Home and Student 2016"  |
                                ProdName == "Computer Game" ~ "Software", 
                                TRUE ~ "Accessories") 
)

#ProdsCats2 %>% group by ()

ProdsCats2$Roww <- 1:nrow(ProdsCats2) 

#write.csv(ProdsCats2,"./csv/ProductCategories.csv")
#write.csv2(ProdsCats2,"./csv/ProductCategories2.csv")


#### B2C b2b SEPPARATION ####

head(ElectoCSV)
#as.data.frame(as.matrix(Electob2bTransacs))

ElectoCSV$TransID <- 1:nrow(ElectoCSV) 

ElectoCSV



ElectroMeltedDF <- 
#tail(
ElectoCSV %>% melt( id.vars = c("TransID")) %>%
 mutate(value = str_trim(value, side = c("both")
  )) %>%
 filter (value !=  "") %>% arrange(TransID)
#) 

#ElectroMeltedDF$variable <- NULL

summary(ElectroMeltedDF$TransID)
summary(ElectoCSV$TransID)

ElectoCSV
9835

tail(ElectroMeltedDF %>% select(TransID) %>% unique())

ElectoCSV %>% select(TransID) %>% unique() %>% 
  subset(!TransID %in% ElectroMeltedDF$TransID)

ElectoCSV %>% filter(TransID %in% c(8707,9506))

#problematic Transactions:
8707
9506

colnames(ElectroMeltedDF)[1] <- "TransID"
ElectroMeltedDF$variable <- NULL
colnames(ElectroMeltedDF)[2] <- "ProdName"




ElectroMeltedCDF <- 
merge(ElectroMeltedDF, ProdsCats2, by.x="ProdName", by.y="ProdName")
#not losing  rows anymore

# 1st version of BusinesClass.
# BusinesTrans <- 
# ElectroMeltedCDF %>%
# filter(ProdCat %in%
# c("Desktop","Laptops","Monitors","Printers", "Keyboar", "Mous.and.Keyboar.Combo" ,"Compu.Mice")
# ) %>% group_by (TransID, ProdCat) %>% summarize( n = n()) %>% filter(n>1)  %>% select(TransID) %>% unique() %>% 
#   ungroup()


#ElectroMeltedCDF %>% select(ProdSuperCat) %>% unique()


# Improved version
BusinesTrans <- 
ElectroMeltedCDF %>%
filter(ProdSuperCat %in%
c("Desktop","Laptops","Monitors","Printers", "MousOrKeyb")) %>% #select(ProdSuperCat) %>% unique() %>%
 group_by (TransID, ProdSuperCat) %>% summarize( n = n()) %>% filter(n>1)  %>% select(TransID) %>% unique() %>%
  ungroup()

#BusinesTrans %>% filter(TransID == 68)
BusinesTrans %>% group_by()
  


#NOT WORKING :(
#ElectroMeltedCDF$SellType <- "B2C"
#ElectroMeltedCDF[ElectroMeltedDF$TransID %in% BusinesTrans$TransID,] %>% filter(TransID == 3178)

#ElectroMeltedCDF %>% filter(TransID == 3178)

 
# ElectroMeltedCDF[ElectroMeltedDF$TransID %in% BusinesTrans$TransID,]$SellType  <- "B2B"
# ElectroMeltedCDF %>% group_by(SellType) %>% summarize(n=n())

#   
ElectroMeltedDF2 <- rbind(
ElectroMeltedCDF  %>%
  subset(TransID %in% BusinesTrans$TransID) %>% mutate(SellType = "B2B")
,ElectroMeltedCDF  %>%
  subset(!TransID %in% BusinesTrans$TransID) %>% mutate(SellType = "B2C")
)
# 

# ElectroMeltedDF2 %>% group_by(SellType) %>% summarize(n=n())

ElectroMeltedDF2 %>% group_by(SellType) %>% summarize(n=n())

#LOoks like working.
ElectroMeltedDF2  %>% filter(TransID == 3178)
#ElectroMeltedCDF  %>% filter(TransID == 3178)


write.csv(
  ElectroMeltedDF2, "./csv/NormalizedTransactions.csv")


write.csv2(
  ElectroMeltedDF2, "./csv/NormalizedTransactions2.csv")

#to inform in the transactions object.
ElectroMeltedDF2 %>% select(TransID,SellType) %>% unique() %>% arrange(TransID)

#shows the rows we are losing!
ElectroMeltedDF %>% 
  subset(!ProdName %in% ProdsCats2$ProdName) %>% select(ProdName) %>% unique()

#products bought 2 times in same transaction
ElectroMeltedDF %>% group_by(TransID,ProdName)  %>%  summarize(n = n()) %>% filter (n>1)


#inform the product category previously calculated

#1st eliminate the 2 rows that are empty:
ElectoCSV2 <-
  ElectoCSV %>% filter(!TransID %in% c(8707,9506))


9808+25
#output df:
9835

ElectoCSV2$SellType <- ElectroMeltedDF2 %>% select(TransID,SellType) %>% unique() %>% arrange(TransID) %>% select(SellType)
#ElectoCSV2$ProductTrans


 B2BTransacs <- 
   ElectoCSV2 %>% filter(SellType == "B2B") 

B2BTransacs$SellType <- NULL
B2BTransacs$TransID <- NULL

write.csv(B2BTransacs, "./csv/B2BTransacs.csv", row.names=F)

 B2CTransacs <- 
   ElectoCSV2 %>% filter(SellType == "B2C") 

B2CTransacs$SellType <- NULL
B2CTransacs$TransID <- NULL

write.csv(B2CTransacs, "./csv/B2CTransacs.csv"#,  col.names=F
          , row.names=F)






# to review tomorrow:
# str(order_trans)v <- order_trans@itemInfo$labels
# 
# vgrep("Laptop",v)
# 
# v[grep("Laptop",v)]<-"Laptop"
# 
# print(v)order_trans@itemInfo$categories<-v
# 
# str(order_trans)

  #group_by(TransID) %>% summarize(n = n())

  
#### Loading transaction files ####
#as.transactional? (df)

B2BElectroTransacs <- retrieve_last_fileT(paste(getwd(),"/csv/",sep=""),"B2B")
  
B2CElectroTransacs <- retrieve_last_fileT(paste(getwd(),"/csv/",sep=""),"B2C")
  
head(B2BElectroTransacs)
inspect(B2BElectroTransacs)
#inspect (sample(B2BElectroTransacs,100)) # You can view the transactions. Is there a way to see a certain # of transactions?
length (B2BElectroTransacs) # Number of transactions.
size (B2BElectroTransacs) # Number of items per transaction
LIST(ElectoTransacs) # Lists the transactions by conversion (LIST must be capitalized)
itemLabels(B2BElectroTransacs) # To see the item labels


head(B2BElectroTransacs)
inspect(B2BElectroTransacs)
#inspect (sample(B2BElectroTransacs,100)) # You can view the transactions. Is there a way to see a certain # of transactions?
length (B2BElectroTransacs) # Number of transactions.
size (B2BElectroTransacs) # Number of items per transaction
LIST(ElectoTransacs) # Lists the transactions by conversion (LIST must be capitalized)
itemLabels(B2BElectroTransacs) # To see the item labels


ProdsCats2$BWCat

str(ElectoTransacs)

TempDFB2B <- 
as.data.frame(B2BElectroTransacs@itemInfo$labels )

colnames(TempDFB2B)[1] <- "ProdName"

TempDFB2B

TempDFB2B2 <- 
  merge(TempDFB2B, ProdsCats2, by.x="ProdName", by.y="ProdName")



B2BElectroTransacs@itemInfo$categories <- TempDFB2B2$BWCat 

#creating transactional for Prod. Category
B2BElectroTransacsAgg <- aggregate(B2BElectroTransacs, by = "categories")

head(itemInfo(B2BElectroTransacsAgg))

inspect(sample(B2BElectroTransacsAgg,100))

rulesB2BBWCat <- apriori(B2BElectroTransacsAgg, parameter = list(supp=0.05, conf=0.9, minlen=1))

inspect(
  rulesB2BBWCat)


library(prabclus)
library(TSP)
install.packages("trimcluster", dependencies = TRUE)
library(trimcluster)
library(arulesViz)

arulesViz::ruleExplorer(
  rulesB2BBWCat)





TempDFB2C <- 
  as.data.frame(B2CElectroTransacs@itemInfo$labels )


#B2BElectroTransacs@itemInfo %>% select (labels,categories)

colnames(TempDFB2C)[1] <- "ProdName"



TempDFB2C2 <- 
  merge(TempDFB2C, ProdsCats2, by.x="ProdName", by.y="ProdName")



B2CElectroTransacs@itemInfo$categories <- TempDFB2C2$BWCat 

#creating transactional for Prod. Category
B2CElectroTransacsAgg <- aggregate(B2CElectroTransacs, by = "categories")

head(itemInfo(B2CElectroTransacsAgg))

inspect(sample(B2CElectroTransacsAgg,100))
  
  rulesB2CBWCat <- apriori(B2CElectroTransacsAgg, parameter = list(supp=0.003, conf=0.55, minlen=1, maxlen=3))
  
  
  GoodB2CRulesBW <- rulesB2CBWCat[!is.redundant(rulesB2CBWCat)]
  
  #we need to include eliminating redundant rules.
  
  #inspect(  GoodB2CRulesBW)
  
  
  
  arulesViz::ruleExplorer(
    GoodB2CRulesBW)
  
  
# number of items per transaction
itemsPerTrans <- as.data.frame(size (ElectoTransacs))
#esquisse::esquisser()
ggplot(data = itemsPerTrans) +
  aes(x = `size(ElectoTransacs)`) +
  geom_histogram(bins = 30, fill = "#0c4c8a") +
  theme_minimal()


ItemLabelsDF <- as.data.frame(itemLabels(ElectoTransacs))


# pendent lo de carregar dataframe + pivotar + eliminar nulls.

# Adult.largeIncome <- Adult[Adult %in% 
#                              "income=large"]




itemLabels(ElectoTransacs)# To see the item labels





summary(itemsPerTrans)

summary(ElectoTransacs)


# data(Adult)
# inspect (Adult) # You can view the transactions. Is there a way to see a certain # of transactions?
# length (Adult) # Number of transactions.
# size (Adult) # Number of items per transaction
# LIST(Adult) # Lists the transactions by conversion (LIST must be capitalized)
# itemLabels(Adult)# To see the item labels
# 

image(sample(ElectoTransacs, 100))


#number of transactions = 9800.

itemFrequencyPlot(ElectoTransacs)
# Adult.largeIncome <- Adult[Adult %in% 
#                              "income=large"]


#

Adult.largeIncome <- Adult[Adult %in% 
                             "income=large"]

## simple plot
itemFrequencyPlot(Adult.largeIncome)

## plot with the averages of the population plotted as a line 
## (for first 72 variables/items)





RulesName <- apriori (ElectoTransacs, parameter = list(minlen=1, maxlen=10#, supp = 0.05, conf = 0.8
                                                       ))
inspection <- inspect(RulesName)
inspection
